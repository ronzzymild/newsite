var navlinks = document.getElementById('navlinks')

function navdisplay(){
    navlinks.style.left = "0px"
}

function navexit(){
    navlinks.style.left = "-315px"
}